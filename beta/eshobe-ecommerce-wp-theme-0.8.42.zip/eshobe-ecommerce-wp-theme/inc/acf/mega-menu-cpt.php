<?php
/**
 * Mega Menu custom post type.
 *
 * @package WM_Theme
 */

function wm_register_mega_menu_cpt() {
    register_post_type(
        'wm_mega_menu',
        array(
            'labels'             => array(
                'name'               => 'مگامنوها',
                'singular_name'      => 'مگامنو',
                'menu_name'          => 'مگامنو',
                'add_new'            => 'افزودن مگامنو',
                'add_new_item'       => 'افزودن مگامنوی جدید',
                'edit_item'          => 'ویرایش مگامنو',
                'new_item'           => 'مگامنوی جدید',
                'view_item'          => 'مشاهده مگامنو',
                'search_items'       => 'جستجوی مگامنو',
                'not_found'          => 'مگامنویی یافت نشد',
                'not_found_in_trash' => 'مگامنویی در زباله‌دان یافت نشد',
                'all_items'          => 'همه مگامنوها',
            ),
            'public'             => false,
            'publicly_queryable' => false,
            'exclude_from_search' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'show_in_admin_bar'  => false,
            'show_in_rest'       => false,
            'menu_icon'          => 'dashicons-screenoptions',
            'menu_position'      => 59,
            'supports'           => array( 'title' ),
            'has_archive'        => false,
            'rewrite'            => false,
            // Borrowing a core capability is safe only because map_meta_cap
            // defaults to false for this CPT. Do not set it to true while
            // these stay core capabilities: that would hijack
            // edit_theme_options site-wide (see inc/ajax/contact-form.php).
            'capabilities'       => array(
                'edit_post'          => 'edit_theme_options',
                'read_post'          => 'edit_theme_options',
                'delete_post'        => 'edit_theme_options',
                'edit_posts'         => 'edit_theme_options',
                'edit_others_posts'  => 'edit_theme_options',
                'publish_posts'      => 'edit_theme_options',
                'read_private_posts' => 'edit_theme_options',
            ),
        )
    );
}
add_action( 'init', 'wm_register_mega_menu_cpt' );
